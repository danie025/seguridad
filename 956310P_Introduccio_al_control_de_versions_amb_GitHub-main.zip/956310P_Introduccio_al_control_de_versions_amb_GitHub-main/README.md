# 956310P_Introduccio_al_control_de_versions_amb_GitHub
956310P introducció al control de versions amb GitHub

OBJECTIUS ESPECÍFICS | TEMARI
- Conèixer els conceptes bàsics del control de versions.
- Gestió de repositoris locals i Sincronització amb GitHub
- Treballant amb branques i Fluxes de treball.

TEMARI
1.- Git: introducció bàsica.
2.- Instal·lació de git
3.- Guardant els canvis
4.- Desfent canvis
5.- Començant amb GitHub: creant repositoris
6.- Sincronització
7.- Treballant amb branques:
  - Crear branques
  - Fusió de branques
8.- Fluxes de treball: GitFlow
